package screenmod;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Uploader {

    private static final Pattern OK_PATTERN =
            Pattern.compile("\"ok\"\\s*:\\s*true");
    private static final Pattern DESC_PATTERN =
            Pattern.compile("\"description\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
    private static final Pattern MESSAGE_PATTERN =
            Pattern.compile("\"message_id\"\\s*:\\s*(\\d+)");

    public static void main(String[] args) {
        String token = "";
        try {
            if (args.length >= 2) {
                token = args[1];
            }
            System.exit(run(args));
        } catch (Throwable t) {
            String message = t.getClass().getSimpleName();
            String detail = t.getMessage();
            if (detail != null) {
                if (!token.isEmpty()) {
                    detail = detail.replace(token, "REDACTED");
                }
                message = message + ": " + detail;
            }
            System.err.println("uploader: " + message);
            System.exit(1);
        }
    }

    private static int run(String[] args) throws Exception {
        if (args.length < 10) {
            System.err.println("usage: Uploader <api_base> <token> <chat_id> <method> <silent> <timeout> <max_dim> <quality> <caption> <file>");
            return 2;
        }

        String apiBase = args[0];
        String token = args[1];
        String chatId = args[2];
        String method = args[3];
        boolean silent = "1".equals(args[4]);
        int timeout = parseInt(args[5], 120);
        if (timeout < 10) {
            timeout = 120;
        }
        int maxDim = parseInt(args[6], 1600);
        if (maxDim < 320) {
            maxDim = 1600;
        } else if (maxDim > 4096) {
            maxDim = 4096;
        }
        int quality = parseInt(args[7], 85);
        if (quality < 1) {
            quality = 85;
        } else if (quality > 100) {
            quality = 100;
        }
        String caption = args[8];
        if (caption.length() > 1024) {
            caption = caption.substring(0, 1024);
        }
        File file = new File(args[9]);
        if (!file.isFile() || file.length() <= 0) {
            System.err.println("uploader: missing or empty file");
            return 3;
        }

        boolean photo = "sendPhoto".equals(method);
        boolean video = "sendVideo".equals(method);
        String field = photo ? "photo" : (video ? "video" : "document");
        String uploadName = file.getName();
        String uploadType = contentType(uploadName);
        Payload payload;
        if (photo) {
            Encoded encoded = encodePhoto(file, maxDim, quality);
            payload = encoded.payload;
            uploadName = encoded.name;
            uploadType = encoded.type;
        } else {
            payload = new FilePayload(file);
        }

        String boundary = "----screenmod" + System.currentTimeMillis()
                + new SecureRandom().nextInt(1000000);
        String base = apiBase;
        while (base.endsWith("/")) {
            base = base.substring(0, base.length() - 1);
        }
        String url = base + "/bot" + token + "/" + method;

        byte[] chatHead = fieldHead(boundary, "chat_id", null, null);
        byte[] chatBody = chatId.getBytes(StandardCharsets.UTF_8);
        byte[] silentHead = silent ? fieldHead(boundary, "disable_notification", null, null) : new byte[0];
        byte[] silentBody = silent ? "true".getBytes(StandardCharsets.UTF_8) : new byte[0];
        byte[] captionHead = caption.isEmpty() ? new byte[0] : fieldHead(boundary, "caption", null, null);
        byte[] captionBody = caption.isEmpty() ? new byte[0] : caption.getBytes(StandardCharsets.UTF_8);
        byte[] fileHead = fieldHead(boundary, field, safeName(uploadName), uploadType);
        byte[] end = ("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8);

        long length = chatHead.length + chatBody.length + 2
                + (silent ? silentHead.length + silentBody.length + 2 : 0)
                + (caption.isEmpty() ? 0 : captionHead.length + captionBody.length + 2)
                + fileHead.length + payload.length() + 2
                + end.length;

        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(Math.min(20000, timeout * 1000));
        conn.setReadTimeout(timeout * 1000);
        conn.setFixedLengthStreamingMode(length);
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        conn.setRequestProperty("User-Agent", "screenmod");

        OutputStream out = new BufferedOutputStream(conn.getOutputStream());
        try {
            out.write(chatHead);
            out.write(chatBody);
            out.write("\r\n".getBytes(StandardCharsets.UTF_8));
            if (silent) {
                out.write(silentHead);
                out.write(silentBody);
                out.write("\r\n".getBytes(StandardCharsets.UTF_8));
            }
            if (!caption.isEmpty()) {
                out.write(captionHead);
                out.write(captionBody);
                out.write("\r\n".getBytes(StandardCharsets.UTF_8));
            }
            out.write(fileHead);
            payload.writeTo(out);
            out.write("\r\n".getBytes(StandardCharsets.UTF_8));
            out.write(end);
        } finally {
            out.close();
        }

        int code = conn.getResponseCode();
        InputStream responseStream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        String body = readAll(responseStream);
        conn.disconnect();

        if (body != null && OK_PATTERN.matcher(body).find()) {
            Matcher message = MESSAGE_PATTERN.matcher(body);
            if (message.find()) {
                System.out.println("ok " + message.group(1));
            }
            return 0;
        }

        String description = extractDescription(body);
        if (description != null) {
            System.err.println("telegram: " + description);
        } else {
            System.err.println("telegram: HTTP " + code);
        }
        return 1;
    }

    private static Encoded encodePhoto(File file, int maxDim, int quality) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                return new Encoded(new FilePayload(file), file.getName(), "image/png");
            }
            int longSide = Math.max(bounds.outWidth, bounds.outHeight);
            int sample = 1;
            while (longSide / (sample * 2) >= maxDim) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            if (bitmap == null) {
                return new Encoded(new FilePayload(file), file.getName(), "image/png");
            }
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            float scale = Math.min(1f, (float) maxDim / Math.max(width, height));
            if (scale < 1f) {
                Bitmap scaled = Bitmap.createScaledBitmap(bitmap,
                        Math.max(1, Math.round(width * scale)),
                        Math.max(1, Math.round(height * scale)), true);
                if (scaled != bitmap) {
                    bitmap.recycle();
                }
                bitmap = scaled;
            }
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, buffer);
            bitmap.recycle();
            byte[] jpeg = buffer.toByteArray();
            if (jpeg.length == 0 || jpeg.length >= file.length()) {
                return new Encoded(new FilePayload(file), file.getName(), "image/png");
            }
            return new Encoded(new BytesPayload(jpeg), jpegName(file.getName()), "image/jpeg");
        } catch (Throwable t) {
            return new Encoded(new FilePayload(file), file.getName(), "image/png");
        }
    }

    private static int parseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static String contentType(String name) {
        String lower = name.toLowerCase();
        if (lower.endsWith(".png")) {
            return "image/png";
        }
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        if (lower.endsWith(".mp4")) {
            return "video/mp4";
        }
        return "application/octet-stream";
    }

    private static byte[] fieldHead(String boundary, String name, String filename, String contentType) {
        StringBuilder builder = new StringBuilder();
        builder.append("--").append(boundary).append("\r\n");
        builder.append("Content-Disposition: form-data; name=\"").append(name).append("\"");
        if (filename != null) {
            builder.append("; filename=\"").append(filename).append("\"");
            builder.append("\r\n");
            builder.append("Content-Type: ").append(contentType);
        }
        builder.append("\r\n\r\n");
        return builder.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static String jpegName(String name) {
        if (name.toLowerCase().endsWith(".png")) {
            return name.substring(0, name.length() - 4) + ".jpg";
        }
        return name + ".jpg";
    }

    private static String safeName(String name) {
        return name.replace('"', '_').replace('\r', '_').replace('\n', '_');
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) {
            return null;
        }
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try {
            byte[] chunk = new byte[8192];
            int read;
            while ((read = in.read(chunk)) > 0) {
                buffer.write(chunk, 0, read);
            }
        } finally {
            in.close();
        }
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    }

    private static String extractDescription(String body) {
        if (body == null) {
            return null;
        }
        Matcher matcher = DESC_PATTERN.matcher(body);
        if (!matcher.find()) {
            return null;
        }
        String value = matcher.group(1)
                .replace("\\\"", "\"")
                .replace("\\\\", "\\");
        if (value.length() > 300) {
            value = value.substring(0, 300);
        }
        return value;
    }

    private interface Payload {
        long length();

        void writeTo(OutputStream out) throws IOException;
    }

    private static final class FilePayload implements Payload {
        private final File file;

        FilePayload(File file) {
            this.file = file;
        }

        public long length() {
            return file.length();
        }

        public void writeTo(OutputStream out) throws IOException {
            InputStream in = new FileInputStream(file);
            try {
                byte[] buffer = new byte[65536];
                int read;
                while ((read = in.read(buffer)) > 0) {
                    out.write(buffer, 0, read);
                }
            } finally {
                in.close();
            }
        }
    }

    private static final class BytesPayload implements Payload {
        private final byte[] bytes;

        BytesPayload(byte[] bytes) {
            this.bytes = bytes;
        }

        public long length() {
            return bytes.length;
        }

        public void writeTo(OutputStream out) throws IOException {
            out.write(bytes);
        }
    }

    private static final class Encoded {
        final Payload payload;
        final String name;
        final String type;

        Encoded(Payload payload, String name, String type) {
            this.payload = payload;
            this.name = name;
            this.type = type;
        }
    }
}
