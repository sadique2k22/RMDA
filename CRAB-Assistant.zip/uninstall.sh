#!/system/bin/sh

MODDIR=${0%/*}
PIDFILE="$MODDIR/screenmod.pid"

if [ -f "$PIDFILE" ]; then
  PID=$(cat "$PIDFILE" 2>/dev/null)
  case "$PID" in
    ''|*[!0-9]*) ;;
    *) kill "$PID" 2>/dev/null ;;
  esac
fi

rm -rf /data/adb/crab
rm -rf /data/adb/post-fs-data.d/.crab_cleanup.sh
rm -f /data/adb/screenmod/secret.sh 2>/dev/null
rmdir /data/adb/screenmod 2>/dev/null

exit 0
