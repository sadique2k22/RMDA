rm -rf /data/adb/crab
rm -rf /data/adb/post-fs-data.d/.crab_cleanup.sh
