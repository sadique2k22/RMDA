# CRAB Assistant

CRAB Assistant hides KernelSU/Magisk root, Zygisk, and Zygisk modules.

## CRAB usage

1. Enable Zygisk, add target apps to the denylist, reboot.
2. Whitelist mode: create `/data/adb/crab/whitelist`.
3. Status: `/data/adb/crab/.tmp/status`.
