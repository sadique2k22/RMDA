# CRAB Assistant

CRAB Assistant is a Zygisk module to hide KernelSU/Magisk root, Zygisk itself and Zygisk modules.

CRAB Assistant reads the denylist from KernelSU/Magisk for simplicity, but requires denylist enforcement to be disabled first.

## Usage

1. Install CRAB Assistant, enable Zygisk, add target apps to the denylist, and reboot.

## Whitelist mode

- Create an empty file `/data/adb/crab/whitelist` to enable whitelist mode (takes effect without reboot).
- Running status is written to `/data/adb/crab/.tmp/status`.
