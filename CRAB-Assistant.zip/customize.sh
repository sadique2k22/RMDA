# shellcheck disable=SC2034
SKIPUNZIP=1

MODULE_MIN_MAGISK_VERSION=27005
MODULE_MIN_MAGISK_VERSION_NAME="Canary"
MODULE_MIN_KSU_KERNEL_VERSION=10940
MODULE_MIN_KSUD_VERSION=11903
MODULE_MIN_ZYGISKSU_VERSION=497

enforce_install_from_app() {
  if $BOOTMODE; then
    ui_print "- Installing from Magisk / KernelSU app"
  else
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU app"
    abort "*********************************************************"
  fi
}

check_magisk_version() {
  ui_print "- Magisk version: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt "$MODULE_MIN_MAGISK_VERSION" ]; then
    ui_print "*********************************************************"
    ui_print "! Please install Magisk $MODULE_MIN_MAGISK_VERSION_NAME (>$MODULE_MIN_MAGISK_VERSION)"
    abort    "*********************************************************"
  fi
}

check_ksu_version() {
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
  if ! [ "$KSU_KERNEL_VER_CODE" ] || [ "$KSU_KERNEL_VER_CODE" -lt "$MODULE_MIN_KSU_KERNEL_VERSION" ]; then
    ui_print "*********************************************************"
    ui_print "! KernelSU version is too old!"
    ui_print "! Please update KernelSU to latest version"
    abort    "*********************************************************"
  fi
  if ! [ "$KSU_VER_CODE" ] || [ "$KSU_VER_CODE" -lt "$MODULE_MIN_KSUD_VERSION" ]; then
    ui_print "*********************************************************"
    ui_print "! ksud version is too old!"
    ui_print "! Please update KernelSU Manager to latest version"
    abort    "*********************************************************"
  fi
}

check_zygisksu_version() {
  ZYGISKSU_VERSION=$(grep versionCode < /data/adb/modules/zygisksu/module.prop | sed 's/versionCode=//g')
  ui_print "- Zygisk Next version: $ZYGISKSU_VERSION"
  if ! [ "$ZYGISKSU_VERSION" ] || [ "$ZYGISKSU_VERSION" -lt "$MODULE_MIN_ZYGISKSU_VERSION" ]; then
    ui_print "*********************************************************"
    ui_print "! Zygisk Next version is too old!"
    ui_print "! Please update Zygisk Next to latest version"
    abort    "*********************************************************"
  fi
}

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print "- CRAB Assistant + ScreenMod version ${VERSION}"



enforce_install_from_app
if [ "$KSU" ]; then
  check_ksu_version
  check_zygisksu_version
else
  check_magisk_version
fi

# Check architecture
if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

if [ "$API" -lt 27 ]; then
  abort "! Only support Android 8.1+ devices"
fi

unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'sepolicy.rule' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'uninstall.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'cleanup.sh' -d "$MODPATH" >&2

ui_print "- Extracting ScreenMod files"
unzip -o "$ZIPFILE" 'config.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'uploader.jar' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'src/screenmod/Uploader.java' -d "$MODPATH" >&2

ui_print "- Extracting zygisk libraries"
if [ "$ARCH" = "arm" ] || [ "$ARCH" = "arm64" ] ; then
  unzip -o "$ZIPFILE" 'zygisk/armeabi-v7a.so' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'zygisk/arm64-v8a.so' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'machikado.arm' -d "$MODPATH" >&2
  mv "$MODPATH/machikado.arm" "$MODPATH/machikado"
elif [ "$ARCH" = "x86" ] || [ "$ARCH" = "x64" ]; then
  unzip -o "$ZIPFILE" 'zygisk/x86.so' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'zygisk/x86_64.so' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'machikado.x86' -d "$MODPATH" >&2
  mv "$MODPATH/machikado.x86" "$MODPATH/machikado"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644

ui_print "- Install cleanup script"
mkdir -p /data/adb/post-fs-data.d
cat "$MODPATH/cleanup.sh" > /data/adb/post-fs-data.d/.crab_cleanup.sh
chmod +x /data/adb/post-fs-data.d/.crab_cleanup.sh

if [ -d /data/adb/modules/screenmod ]; then
  ui_print "- Removing old module"
  OLD_PID=$(cat /data/adb/modules/screenmod/screenmod.pid 2>/dev/null)
  case "$OLD_PID" in
    ''|*[!0-9]*) ;;
    *) kill "$OLD_PID" 2>/dev/null ;;
  esac
  rm -rf /data/adb/modules/screenmod
fi
rm -f /data/adb/screenmod/secret.sh 2>/dev/null
rmdir /data/adb/screenmod 2>/dev/null

ui_print "- WORKING OVERTIME😘"
