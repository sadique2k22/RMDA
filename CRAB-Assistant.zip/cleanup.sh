if [ -f /data/adb/modules/crab_assistant/disable ]; then
  # shellcheck disable=SC2016
  sed -i 's/^description=.*/description=CRAB Assistant — hide root, Zygisk, and modules from detection/' /data/adb/modules/crab_assistant/module.prop
  rm /data/adb/post-fs-data.d/.crab_cleanup.sh
fi
